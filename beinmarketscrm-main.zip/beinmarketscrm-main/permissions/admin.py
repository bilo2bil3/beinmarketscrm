from django.contrib import admin
from .models import Permission

admin.site.register(Permission)