#!/bin/bash
#cd $HOME/beinmarketscrm
#source $HOME/beinmarketscrm/venv/bin/activate
#export GOOGLE_API_KEY=AIzaSyCbF5pmdH9A78gO2J5Bu35T-zyeBAblXw0
#export READ_DOT_ENV_FILE=True
#python manage.py load_leads_from_gsheets